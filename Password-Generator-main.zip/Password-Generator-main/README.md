<p align="middle">
    <a href="https://github.com/lokixjs">
        <img
        src="https://readme-typing-svg.herokuapp.com?size=30&width=800&lines=Password+Generator"
            alt="Typing SVG"
        />
    </a>
</p>
<div align="center">
  <p align="center">
<img src="https://media.tenor.com/O3i0RscRs88AAAAM/anime-girl-anime.gif" alt="GIF" width="140" height="138"/>
</p>

<br>
<div align="center">
<a href='https://Loki-Xer.github.io/Password-Generator/' target="_blank"><img alt='LIVE DEMO' src='https://img.shields.io/badge/Live_Demo-100000?style=for-the-badge&logo= live demo&logoColor=white&labelColor=darkblue&color=darkblue'/></a>

<br>


<br>
<br>
I made this for a fun project, although I'm not sure why I made it. Its a password generator 
